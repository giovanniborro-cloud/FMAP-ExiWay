using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace SchneiderLoader;

// Direct native Windows Winsock Bluetooth Classic client: AF_BTH / RFCOMM channel 1.
// No Modbus, virtual COM port or TCP tunnel is involved.
internal sealed class BluetoothRfcommClient : IDisposable
{
    private const int AfBth = 32;
    private const int SockStream = 1;
    private const int BthProtoRfcomm = 3;
    private const int SockaddrBthLength = 40;
    private const int SolSocket = 0xFFFF;
    private const int SoRcvTimeout = 0x1006;
    private const int SoSndTimeout = 0x1005;
    private static readonly IntPtr InvalidSocket = new(-1);
    private IntPtr _socket = InvalidSocket;
    private bool _wsaStarted;
    private readonly object _writeLock = new();
    public bool Connected => _socket != InvalidSocket;

    public static ulong ParseAddress(string text)
    {
        string digits = new(text.Where(Uri.IsHexDigit).ToArray());
        if (digits.Length != 12 || !ulong.TryParse(digits, System.Globalization.NumberStyles.HexNumber,
                System.Globalization.CultureInfo.InvariantCulture, out var mac))
            throw new FormatException("Indirizzo Bluetooth non valido. Inserire 12 cifre esadecimali, es. 00:11:22:33:44:55.");
        return mac;
    }

    public void Connect(string macText, uint channel = 1)
    {
        Dispose();
        ulong address = ParseAddress(macText);
        if (address == 0) throw new FormatException("Il MAC Bluetooth 00:00:00:00:00:00 non è valido.");
        if (channel is < 1 or > 30) throw new ArgumentOutOfRangeException(nameof(channel), "Il canale RFCOMM deve essere tra 1 e 30.");
        IntPtr wsadata = Marshal.AllocHGlobal(512);
        try
        {
            int rc = WSAStartup(0x0202, wsadata);
            if (rc != 0) throw new Win32Exception(rc, "WSAStartup fallita");
            _wsaStarted = true;
        }
        finally { Marshal.FreeHGlobal(wsadata); }

        _socket = socket(AfBth, SockStream, BthProtoRfcomm);
        if (_socket == InvalidSocket) ThrowSocketError("Apertura socket Bluetooth");

        // sockaddr_bth: USHORT addressFamily at 0; padding 2-7; ULONGLONG btAddr at 8;
        // GUID serviceClassId at 16 (zero for explicit port); ULONG port at 32.
        byte[] sockaddr = new byte[SockaddrBthLength];
        BitConverter.GetBytes((ushort)AfBth).CopyTo(sockaddr, 0);
        BitConverter.GetBytes(address).CopyTo(sockaddr, 8);
        BitConverter.GetBytes(channel).CopyTo(sockaddr, 32);
        if (connect(_socket, sockaddr, sockaddr.Length) != 0)
        {
            int error = WSAGetLastError();
            if (error == 10049)
                throw new Win32Exception(error, $"Connessione RFCOMM: MAC {FormatAddress(address)}, canale {channel}. Windows segnala indirizzo remoto o canale non valido (10049)");
            throw new Win32Exception(error, $"Connessione RFCOMM: MAC {FormatAddress(address)}, canale {channel}");
        }
        SetTimeout(SoRcvTimeout, 1000);
        SetTimeout(SoSndTimeout, 5000);
    }

    public static string FormatAddress(ulong address) => string.Join(":", Enumerable.Range(0, 6).Select(i => ((address >> (8 * (5 - i))) & 0xFF).ToString("X2")));

    private void SetTimeout(int option, int ms)
    {
        var bytes = BitConverter.GetBytes(ms);
        if (setsockopt(_socket, SolSocket, option, bytes, bytes.Length) != 0)
            ThrowSocketError("Configurazione timeout");
    }

    public void SendAscii(string data)
    {
        if (!Connected) throw new InvalidOperationException("Non connesso");
        byte[] payload = Encoding.ASCII.GetBytes(data);
        lock (_writeLock)
        {
            int offset = 0;
            while (offset < payload.Length)
            {
                byte[] part = payload[offset..];
                int sent = send(_socket, part, part.Length, 0);
                if (sent <= 0) ThrowSocketError("Invio Bluetooth");
                offset += sent;
            }
        }
    }

    public int Receive(byte[] buffer)
    {
        if (!Connected) return 0;
        int count = recv(_socket, buffer, buffer.Length, 0);
        if (count >= 0) return count;
        int error = WSAGetLastError();
        if (error == 10060) return -1; // expected receive timeout
        if (error is 10004 or 10038 or 10053 or 10054) return 0; // shutdown / disconnect
        throw new Win32Exception(error, "Ricezione Bluetooth fallita");
    }

    private static void ThrowSocketError(string action) => throw new Win32Exception(WSAGetLastError(), action);

    public void Dispose()
    {
        IntPtr s = _socket;
        _socket = InvalidSocket;
        if (s != InvalidSocket)
        {
            shutdown(s, 2);
            closesocket(s);
        }
        if (_wsaStarted) { WSACleanup(); _wsaStarted = false; }
    }

    [DllImport("Ws2_32.dll", SetLastError = true)] private static extern int WSAStartup(ushort version, IntPtr data);
    [DllImport("Ws2_32.dll")] private static extern int WSACleanup();
    [DllImport("Ws2_32.dll")] private static extern IntPtr socket(int af, int type, int protocol);
    [DllImport("Ws2_32.dll")] private static extern int connect(IntPtr s, byte[] name, int namelen);
    [DllImport("Ws2_32.dll")] private static extern int setsockopt(IntPtr s, int level, int optname, byte[] optval, int optlen);
    [DllImport("Ws2_32.dll")] private static extern int send(IntPtr s, byte[] buf, int len, int flags);
    [DllImport("Ws2_32.dll")] private static extern int recv(IntPtr s, byte[] buf, int len, int flags);
    [DllImport("Ws2_32.dll")] private static extern int shutdown(IntPtr s, int how);
    [DllImport("Ws2_32.dll")] private static extern int closesocket(IntPtr s);
    [DllImport("Ws2_32.dll")] private static extern int WSAGetLastError();
}
