# OVA-GEN3 / Exitwai2 — Bluetooth Classic Schneider Exiway

Applicazione **Windows Forms (.NET 10)** che comunica direttamente tramite Bluetooth Classic **RFCOMM canale 1** con i controller Schneider `NCUxxxxxxxx`. I vecchi moduli Modbus RTU, COM, TCP ed Ethernet sono stati eliminati come richiesto.

## Uso
1. Apri `SchneiderLoader.slnx` in Visual Studio con supporto .NET 10 e avvia il progetto.
2. Disconnetti l'app eCommission dal tablet prima di collegarti da Windows.
3. Premi **Cerca NCU** e seleziona il controller; il MAC completo viene compilato automaticamente. Se non appare, recupera il MAC Bluetooth completo e inseriscilo manualmente.
4. Premi **Connetti RFCOMM 1**. L'implementazione usa Winsock `AF_BTH`, canale 1, senza creare una COM virtuale.
5. Premi **Login 323**. La password predefinita e' la parte di 8 caratteri dopo `NCU`; ad esempio `NCU33fab915` -> `33fab915`. Il protocollo riempie il campo a 15 caratteri con spazi.
6. Dopo risposta `$0013230000*` premi **Lettura 007**, **Leggi 134** oppure invia telegrammi ASCII con `TX`.

## Trame verificate nella cattura PEAQ 2026-11-17
- TX login: `$00132301533fab915       00*` (7 spazi prima di `00*`)
- RX login: `$0013230000*`
- TX lettura: `$00100700000*`
- RX lettura: `$00100700004000300*`
- TX next-address: `$00113400000*`

## Attenzioni
- **Il collegamento diretto non aggira l'associazione Bluetooth richiesta da Windows**: il pairing sicuro e le restrizioni del controller dipendono dal firmware e dallo stack Windows. Se Windows mostra un errore di pairing, l'app registrera' il codice WinSock utile per la diagnosi.
- Il campo *MAC Bluetooth* richiede 12 cifre HEX, e' differente dal nome NCU di 11 caratteri.
- I comandi di scrittura vengono inviati senza limitazioni dalla console: utilizzarla soltanto su banco prova isolato.
- La risposta `323` viene trattata come ACK ricevuto, non come verifica crittografica della password.
- L'eseguibile **non** e' stato compilato o testato su Windows in questo ambiente. Compilare in Visual Studio .NET 10.
- Non vengono memorizzate password su disco; il log non stampa il payload del login 323.

## Progetto
- `MainForm.cs`: UI, scan, connessione, TX/RX, diagnostica.
- `BluetoothRfcommClient.cs`: wrapper Winsock nativo RFCOMM, canale 1.
- `BluetoothDiscovery.cs`: scansione Bluetooth Classic con API native Windows.
- `SchneiderProtocol.cs`: codifica trame ASCII Schneider.

## Correzione errore SerialPort
Se la versione Bluetooth e' stata estratta sopra la versione precedente, possono rimanere `ModbusRtuClient.cs` e `ModbusTcpClient.cs`. Il file `SchneiderLoader.csproj` ora li esclude dalla compilazione. Si possono anche eliminare manualmente: non sono usati. Non aggiungere `System.IO.Ports`.


## Diagnostica 10049 (aggiornamento)

Il codice Windows 10049 (`WSAEADDRNOTAVAIL`) restituito da `connect()` per AF_BTH indica indirizzo remoto **o canale RFCOMM** non valido, non un errore della password Schneider.

1. Premi **Cerca NCU**; seleziona `NCU33fab915`.
2. Controlla che il campo **MAC Bluetooth** contenga **12 cifre esadecimali** (`AA:BB:CC:DD:EE:FF`), non il nome NCU, né gli 8 caratteri di password.
3. La nuova versione registra nel log nome, MAC completo, stato paired e canale 1 prima della chiamata a `connect()`.
4. Se 10049 persiste con il MAC corretto, verifica che la periferica sia visibile e che il canale 1 sia effettivamente supportato dal firmware; il canale proviene dall'analisi APK, non è stato validato dal PC.
5. In caso di problema di pairing, il codice tipico è differente (per esempio 10013).

Non vengono aggiunti Modbus TCP, seriali COM o dipendenze System.IO.Ports.
