using System.IO.Ports;

namespace SchneiderLoader;

internal sealed class ModbusRtuClient : IDisposable
{
    private readonly SerialPort _port;

    public ModbusRtuClient(string portName, int baudRate = 115200)
    {
        _port = new SerialPort(portName, baudRate, Parity.Even, 8, StopBits.One)
        {
            Handshake = Handshake.None,
            ReadTimeout = 1500,
            WriteTimeout = 1500
        };
        _port.Open();
    }

    public ushort[] ReadHoldingRegisters(byte slaveId, ushort startAddress, ushort count)
    {
        if (count is 0 or > 125)
            throw new ArgumentOutOfRangeException(nameof(count), "La quantità deve essere compresa tra 1 e 125 registri.");

        byte[] request = [slaveId, 0x03, (byte)(startAddress >> 8), (byte)startAddress,
            (byte)(count >> 8), (byte)count, 0, 0];
        ushort crc = ComputeCrc(request.AsSpan(0, 6));
        request[6] = (byte)crc;
        request[7] = (byte)(crc >> 8);

        _port.DiscardInBuffer();
        _port.Write(request, 0, request.Length);

        byte[] header = ReadExactly(3);
        if (header[0] != slaveId)
            throw new IOException($"Risposta ricevuta dallo slave {header[0]}, atteso {slaveId}.");
        if (header[1] == 0x83)
        {
            byte[] exception = ReadExactly(2);
            ValidateCrc([.. header, .. exception]);
            throw new ModbusExceptionResponseException(header[2]);
        }
        if (header[1] != 0x03)
            throw new IOException($"Funzione Modbus inattesa: 0x{header[1]:X2}.");

        int byteCount = header[2];
        if (byteCount != count * 2)
            throw new IOException($"Lunghezza risposta inattesa: {byteCount} byte.");

        byte[] payloadAndCrc = ReadExactly(byteCount + 2);
        byte[] response = [.. header, .. payloadAndCrc];
        ValidateCrc(response);

        ushort[] values = new ushort[count];
        for (int i = 0; i < count; i++)
            values[i] = (ushort)((payloadAndCrc[i * 2] << 8) | payloadAndCrc[i * 2 + 1]);
        return values;
    }

    private byte[] ReadExactly(int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
            offset += _port.Read(buffer, offset, count - offset);
        return buffer;
    }

    private static void ValidateCrc(byte[] frame)
    {
        ushort expected = ComputeCrc(frame.AsSpan(0, frame.Length - 2));
        ushort actual = (ushort)(frame[^2] | (frame[^1] << 8));
        if (actual != expected)
            throw new IOException("CRC Modbus non valido nella risposta.");
    }

    private static ushort ComputeCrc(ReadOnlySpan<byte> bytes)
    {
        ushort crc = 0xFFFF;
        foreach (byte value in bytes)
        {
            crc ^= value;
            for (int bit = 0; bit < 8; bit++)
                crc = (ushort)((crc & 1) != 0 ? (crc >> 1) ^ 0xA001 : crc >> 1);
        }
        return crc;
    }

    public void Dispose()
    {
        if (_port.IsOpen)
            _port.Close();
        _port.Dispose();
    }
}

internal sealed class ModbusExceptionResponseException(byte exceptionCode)
    : IOException($"Lo slave ha risposto con un'eccezione Modbus (codice 0x{exceptionCode:X2}).")
{
    public byte ExceptionCode { get; } = exceptionCode;
}
