using System.Net.Sockets;

namespace SchneiderLoader;

internal sealed class ModbusTcpClient
{
    private static int _nextTransactionId;

    public static ushort[] ReadInputRegisters(string host, int port, byte unitId, ushort startAddress, ushort count)
    {
        if (count is 0 or > 125)
            throw new ArgumentOutOfRangeException(nameof(count), "La quantità deve essere compresa tra 1 e 125 registri.");

        ushort transactionId = (ushort)Interlocked.Increment(ref _nextTransactionId);
        byte[] request =
        [
            (byte)(transactionId >> 8), (byte)transactionId,
            0, 0,
            0, 6,
            unitId,
            0x04,
            (byte)(startAddress >> 8), (byte)startAddress,
            (byte)(count >> 8), (byte)count
        ];

        using var client = new TcpClient();
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(3));
        client.ConnectAsync(host, port, timeout.Token).AsTask().GetAwaiter().GetResult();
        using NetworkStream stream = client.GetStream();
        stream.ReadTimeout = 3000;
        stream.WriteTimeout = 3000;
        stream.Write(request, 0, request.Length);

        byte[] header = ReadExactly(stream, 7);
        ushort responseTransactionId = (ushort)((header[0] << 8) | header[1]);
        ushort protocolId = (ushort)((header[2] << 8) | header[3]);
        ushort responseLength = (ushort)((header[4] << 8) | header[5]);
        byte responseUnitId = header[6];

        if (responseTransactionId != transactionId)
            throw new IOException($"Transaction ID inatteso: {responseTransactionId}, atteso {transactionId}.");
        if (protocolId != 0)
            throw new IOException($"Protocol ID Modbus TCP non valido: {protocolId}.");
        if (responseUnitId != unitId)
            throw new IOException($"Unit ID ricevuto {responseUnitId}, atteso {unitId}.");
        if (responseLength < 3 || responseLength > 254)
            throw new IOException($"Lunghezza risposta Modbus TCP non valida: {responseLength}.");

        byte[] pdu = ReadExactly(stream, responseLength - 1);
        if (pdu[0] == 0x84)
            throw new ModbusExceptionResponseException(pdu[1]);
        if (pdu[0] != 0x04)
            throw new IOException($"Funzione Modbus TCP inattesa: 0x{pdu[0]:X2}.");

        int byteCount = pdu[1];
        if (byteCount != count * 2 || pdu.Length != byteCount + 2)
            throw new IOException($"Lunghezza dati inattesa: {byteCount} byte.");

        ushort[] values = new ushort[count];
        for (int i = 0; i < count; i++)
            values[i] = (ushort)((pdu[2 + i * 2] << 8) | pdu[3 + i * 2]);
        return values;
    }

    private static byte[] ReadExactly(NetworkStream stream, int count)
    {
        byte[] buffer = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read == 0)
                throw new EndOfStreamException("La connessione TCP è stata chiusa prima della risposta completa.");
            offset += read;
        }
        return buffer;
    }
}
